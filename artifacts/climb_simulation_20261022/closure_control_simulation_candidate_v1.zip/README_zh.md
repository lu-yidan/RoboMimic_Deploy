# G1 钩爪攀爬仿真候选包

此包只复现一个已审计工况。包含黑色钩爪、横杆场景、参考轨迹、148维观测策略和必要源码；不连接真机。
这是候选包，完整二阶段选模结果另行记录。控制器依赖仿真真实接触，策略读取真实杆偏移，并非视觉自主攀爬。

进入本目录，用匹配依赖的 Python 运行：

```powershell
python -m deploy_mujoco.run_packaged_geometry --verify-only
python -m deploy_mujoco.run_packaged_geometry --output replay
python -m deploy_mujoco.run_packaged_geometry --output viewer_replay --viewer
```

输出目录必须不存在。头部界面关闭会结束运行，不能计作完整成功。包内脚本核对所有文件和主要依赖版本；完整运行后将七组数组与原审计轨迹逐项精确比较。
同机独立路径复现通过后，仍不能推断其他操作系统、硬件或浮点库上的逐位一致。原始审计保持原样放在 evidence，绝对路径字段仅作来源记录；运行路径由 release_manifest.json 的相对路径定义。
